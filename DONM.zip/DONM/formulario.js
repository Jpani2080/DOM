// Array con las respuestas correctas
const respuestasCorrectas = {
    pregunta1: "Madrid",
    pregunta2: "Shakespeare"
  };
  
  let puntuacionTotal = 0;
  let resultadosHistoricos = [];
  
  document.getElementById('preguntasFormulario').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Obtenemos todas las respuestas seleccionadas por el usuario
    const respuestasUsuario = Array.from(document.querySelectorAll('input[name]:checked')).map(input => input.value);
  
    // Calculamos la puntuación para cada pregunta
    let puntuacionPregunta1 = respuestasCorrectas.pregunta1 === respuestasUsuario[0] ? 1 : 0;
    let puntuacionPregunta2 = respuestasCorrectas.pregunta2 === respuestasUsuario[1] ? 1 : 0;
  
    // Mostramos el resultado de cada pregunta
    mostrarResultadoIndividual('pregunta1', respuestasUsuario[0], puntuacionPregunta1);
    mostrarResultadoIndividual('pregunta2', respuestasUsuario[1], puntuacionPregunta2);
  
    // Calculamos la puntuación total
    puntuacionTotal = puntuacionPregunta1 + puntuacionPregunta2;
  
    // Mostramos el resultado final
    mostrarResultadoFinal(puntuacionTotal);
  });
  
  function mostrarResultadoIndividual(idPregunta, respuestaUsuario, puntuacion) {
    const preguntaElemento = document.querySelector(`#pregunta${idPregunta}`);
    const resultadoDiv = document.createElement('div');
    
    resultadoDiv.className = 'resultado-individual';
    resultadoDiv.innerHTML = `
      <p>¿${preguntaElemento.textContent}?</p>
      <p>Respuesta seleccionada: ${respuestaUsuario}</p>
      <p>Puntuación: ${puntuacion} de 1</p>
      ${puntuacion ? `<p class="correcto">Correcta!</p>` : `<p class="incorrecto">Incorrecta.</p>`}
    `;
    
    preguntaElemento.parentNode.insertBefore(resultadoDiv, preguntaElemento.nextSibling);
  }
  
  function mostrarResultadoFinal(puntuacionTotal) {
    const resultadoDiv = document.createElement('div');
    resultadoDiv.className = 'resultado-final';
    resultadoDiv.innerHTML = `
      <h3>Resultados finales:</h3>
      <p>Puntuación total: ${puntuacionTotal} de 2</p>
      <p>Respuestas correctas: ${respuestasCorrectas.pregunta1}, ${respuestasCorrectas.pregunta2}</p>
    `;
    document.getElementById('resultados').appendChild(resultadoDiv);
  }
  
  function guard```
  